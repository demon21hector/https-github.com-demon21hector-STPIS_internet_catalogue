<?php
/* Smarty version 3.1.29, created on 2017-06-23 13:55:36
  from "E:\xampp\htdocs\myshop.local\views\admin\adminLeftcoloumn.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_594d01b8079d12_08844203',
  'file_dependency' => 
  array (
    '78b12602a24b586319ccae2fea6787d58b2bcbc4' => 
    array (
      0 => 'E:\\xampp\\htdocs\\myshop.local\\views\\admin\\adminLeftcoloumn.tpl',
      1 => 1498218932,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_594d01b8079d12_08844203 ($_smarty_tpl) {
?>


<div id="leftColumn">
    <div id="leftMenu">
        <div class="menuCaption">Menu:</div>
        <a href="/admin/">Main</a><br />
        <a href="/admin/category/">Categories</a><br />
        <a href="/admin/products/">Products</a><br />
        <a href="/admin/orders/">Orders</a>
    </div>
</div><?php }
}
