<?php
/* Smarty version 3.1.29, created on 2017-06-13 19:16:18
  from "E:\xampp\htdocs\myshop.local\views\default\footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_59401de2777dd7_04184528',
  'file_dependency' => 
  array (
    'd43462d7c6c285f11a1f1dfc569fe812d372bcf6' => 
    array (
      0 => 'E:\\xampp\\htdocs\\myshop.local\\views\\default\\footer.tpl',
      1 => 1467545713,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59401de2777dd7_04184528 ($_smarty_tpl) {
?>
</div> 


<div id="footer">footer</div>

</body>

</html><?php }
}
