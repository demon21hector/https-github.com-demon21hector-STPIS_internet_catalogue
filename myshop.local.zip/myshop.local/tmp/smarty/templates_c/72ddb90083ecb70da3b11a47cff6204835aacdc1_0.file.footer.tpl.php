<?php
/* Smarty version 3.1.29, created on 2018-06-16 12:30:48
  from "C:\xampp\htdocs\myshop.local\views\default\footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5b24e6d8a27461_30109028',
  'file_dependency' => 
  array (
    '72ddb90083ecb70da3b11a47cff6204835aacdc1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\myshop.local\\views\\default\\footer.tpl',
      1 => 1501452526,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b24e6d8a27461_30109028 ($_smarty_tpl) {
?>
</div> 


<div id="footer">footer</div>

</body>

</html><?php }
}
