<?php
/* Smarty version 3.1.29, created on 2017-06-18 21:11:16
  from "E:\xampp\htdocs\myshop.local\views\admin\adminFooter.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5946d054310e55_16786961',
  'file_dependency' => 
  array (
    'ee3fbfe56c3012c89f3fcfde30e2f203bf6f6333' => 
    array (
      0 => 'E:\\xampp\\htdocs\\myshop.local\\views\\admin\\adminFooter.tpl',
      1 => 1497812814,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5946d054310e55_16786961 ($_smarty_tpl) {
?>


</div> 
<div id="footer">
    Footer-admin
</div>

</body>
</html><?php }
}
