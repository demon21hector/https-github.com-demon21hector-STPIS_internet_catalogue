<?php
/* Smarty version 3.1.29, created on 2016-07-04 10:17:06
  from "D:\xampp\htdocs\myshop.local\views\default\footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_577a1b82cf5c44_98844061',
  'file_dependency' => 
  array (
    '6c03aed73559d06b39c40dfd00257c308638a792' => 
    array (
      0 => 'D:\\xampp\\htdocs\\myshop.local\\views\\default\\footer.tpl',
      1 => 1467614247,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_577a1b82cf5c44_98844061 ($_smarty_tpl) {
?>
</div> 


<div id="footer">footer</div>

</body>

</html><?php }
}
